"""
VoidAI v2 — Message handler
FIX: Removed badge prefix from all AI replies (no more "🔥 Void Flash · VoidAI v2").
     Plain text replies — no parse_mode, so no ** stars showing up.
     Voice reply sends clean caption without markdown symbols.
     Image analysis passes raw bytes for Telegraph reverse image search.
"""

import os, logging, base64
import httpx
from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ChatAction

from config import is_banned, BOT_TOKEN
from core.session import get_model, add_to_history, get_history, get_voice
from core.limiter import check_limit, record_usage
from core.ai_provider import ask_ai
from core.search import web_search, format_search_results
from core.image_analysis import upload_to_telegraph, reverse_image_search, summarise_image_search
from core.voice import text_to_speech, clean_for_tts

logger = logging.getLogger(__name__)

_TG_FILE_BASE = f"https://api.telegram.org/file/bot{BOT_TOKEN}/"


async def _download_bytes(url: str) -> bytes | None:
    """Download raw bytes from URL."""
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.get(url)
        r.raise_for_status()
        return r.content
    except Exception as e:
        logger.warning("Download error: %s", e)
        return None


async def _send_voice_reply(update: Update, text: str, voice_name: str):
    """Send AI answer as a Telegram voice note. Caption is plain text."""
    clean = clean_for_tts(text)
    audio_path = await text_to_speech(clean, voice_name)
    if audio_path:
        try:
            caption = text[:900] if len(text) <= 900 else text[:897] + "…"
            with open(audio_path, "rb") as f:
                await update.message.reply_voice(voice=f, caption=caption)
        except Exception as e:
            logger.warning("Voice send error: %s", e)
            await update.message.reply_text(text)
        finally:
            try:
                os.unlink(audio_path)
            except Exception:
                pass
    else:
        await update.message.reply_text(text)


async def message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    uid  = user.id

    if is_banned(uid):
        await update.message.reply_text("You are banned from using VoidAI.")
        return

    model = get_model(uid)
    photo = update.message.photo

    # ── Image message ──────────────────────────────────────────────────────────
    if photo:
        if not check_limit(uid, model, "images"):
            await update.message.reply_text(
                "Image analysis limit reached for this hour. Try again later."
            )
            return
        record_usage(uid, "images")
        await update.message.chat.send_action(ChatAction.UPLOAD_PHOTO)

        tg_file  = await context.bot.get_file(photo[-1].file_id)
        file_url = _TG_FILE_BASE + tg_file.file_path

        # Download raw bytes (needed for Telegraph + base64)
        img_bytes = await _download_bytes(file_url)
        if not img_bytes:
            await update.message.reply_text("Failed to download image. Please try again.")
            return

        image_b64 = base64.b64encode(img_bytes).decode()
        caption   = update.message.caption or "Describe this image in detail."

        extra_context = None
        if model == "pro":
            # Real reverse image search via Telegraph upload
            rev_results   = await reverse_image_search(caption, max_results=3, image_bytes=img_bytes)
            extra_context = summarise_image_search(rev_results)
            web_res = await web_search(caption, max_results=3)
            from core.search import format_search_results
            raw = format_search_results(web_res)
            if raw and raw != "No results found.":
                extra_context = ((extra_context + "\n" + raw) if extra_context else raw)[:800]

        await update.message.chat.send_action(ChatAction.TYPING)
        answer = await ask_ai(
            prompt=caption,
            history=get_history(uid),
            image_b64=image_b64,
            extra_context=extra_context,
        )

        add_to_history(uid, "user",      f"[Image] {caption}")
        add_to_history(uid, "assistant", answer)

        voice_on, voice_name = get_voice(uid)
        if voice_on:
            await _send_voice_reply(update, answer, voice_name)
        else:
            await update.message.reply_text(answer)
        return

    # ── Text message ───────────────────────────────────────────────────────────
    text = update.message.text or ""
    if not text:
        return

    if not check_limit(uid, model, "messages"):
        await update.message.reply_text(
            "Message limit reached for this hour. Wait for limit to reset."
        )
        return
    record_usage(uid, "messages")
    await update.message.chat.send_action(ChatAction.TYPING)

    extra_context = None
    if model == "pro":
        if check_limit(uid, model, "searches"):
            record_usage(uid, "searches")
            results = await web_search(text, max_results=4)
            from core.search import format_search_results
            raw = format_search_results(results)
            if raw and raw != "No results found.":
                extra_context = raw[:800]

    answer = await ask_ai(
        prompt=text,
        history=get_history(uid),
        extra_context=extra_context,
    )

    add_to_history(uid, "user",      text)
    add_to_history(uid, "assistant", answer)

    voice_on, voice_name = get_voice(uid)
    if voice_on:
        await _send_voice_reply(update, answer, voice_name)
    else:
        await update.message.reply_text(answer)
