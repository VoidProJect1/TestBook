"""
VoidAI v2 — Admin handler
FIX: Added /delkey command and inline delete buttons for API keys.
     Removed "VoidAI v2" branding from admin messages.
"""

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from config import get_config, save_config, is_admin, get_admin_ids, BOOTSTRAP_ADMIN_ID
from core.limiter import _usage, _window

logger = logging.getLogger(__name__)


def _require_admin(uid: int) -> bool:
    return is_admin(uid)


# ── /admin ────────────────────────────────────────────────────────────────────
async def admin_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not _require_admin(uid):
        await update.message.reply_text("Admin access required.")
        return

    cfg = get_config()
    gemini_count  = len(cfg.get("gemini_keys", []))
    grok_count    = len(cfg.get("grok_keys", []))
    mistral_count = len(cfg.get("mistral_keys", []))
    banned_count  = len(cfg.get("banned_users", []))
    admin_count   = len(cfg.get("admin_ids", []))

    buttons = [
        [InlineKeyboardButton("🔑 Manage API Keys", callback_data="admin:keys")],
        [InlineKeyboardButton("📊 Usage Stats",      callback_data="admin:stats")],
        [InlineKeyboardButton("🚫 Banned Users",     callback_data="admin:bans")],
        [InlineKeyboardButton("⚙️ Set Limits",       callback_data="admin:limits")],
    ]

    await update.message.reply_text(
        "Admin Panel\n\n"
        f"Admins: {admin_count}\n"
        f"Gemini Keys: {gemini_count}\n"
        f"Grok Keys: {grok_count}\n"
        f"Mistral Keys: {mistral_count}\n"
        f"Banned users: {banned_count}\n\n"
        "Commands:\n"
        "/addadmin <user_id> — Add admin\n"
        "/ban <user_id> — Ban/unban user\n"
        "/limit <multiplier> — Set global limit\n"
        "/limit <user_id> <multiplier> — Per-user limit\n"
        "/stats — Usage overview\n"
        "/addkey gemini <key> — Add Gemini key\n"
        "/addkey grok <key> — Add Grok key\n"
        "/addkey mistral <key> — Add Mistral key\n"
        "/delkey gemini <index> — Delete Gemini key by index\n"
        "/delkey grok <index> — Delete Grok key by index\n"
        "/delkey mistral <index> — Delete Mistral key by index\n",
        reply_markup=InlineKeyboardMarkup(buttons),
    )


# ── /addadmin ─────────────────────────────────────────────────────────────────
async def addadmin_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not _require_admin(uid):
        await update.message.reply_text("Admin access required.")
        return

    if not context.args:
        await update.message.reply_text("Usage: /addadmin <user_id>")
        return

    try:
        target_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("Invalid user ID.")
        return

    cfg = get_config()
    if target_id not in cfg["admin_ids"]:
        cfg["admin_ids"].append(target_id)
        save_config(cfg)
        await update.message.reply_text(f"User {target_id} is now an admin.")
        try:
            await context.bot.send_message(
                chat_id=target_id,
                text="You have been granted admin access to VoidAI. Use /admin to open the panel."
            )
        except Exception:
            pass
    else:
        cfg["admin_ids"].remove(target_id)
        save_config(cfg)
        await update.message.reply_text(f"User {target_id} admin access removed.")


# ── /ban ──────────────────────────────────────────────────────────────────────
async def ban_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not _require_admin(uid):
        return

    target_id = None
    if update.message.reply_to_message:
        target_id = update.message.reply_to_message.from_user.id
    elif context.args:
        try:
            target_id = int(context.args[0])
        except ValueError:
            pass

    if not target_id:
        await update.message.reply_text("Usage: /ban <user_id> or reply to a message")
        return

    cfg = get_config()
    if target_id not in cfg["banned_users"]:
        cfg["banned_users"].append(target_id)
        save_config(cfg)
        await update.message.reply_text(f"User {target_id} has been banned.")
    else:
        cfg["banned_users"].remove(target_id)
        save_config(cfg)
        await update.message.reply_text(f"User {target_id} has been unbanned.")


# ── /limit ────────────────────────────────────────────────────────────────────
async def limit_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not _require_admin(uid):
        return

    args = context.args
    cfg = get_config()

    if len(args) == 2:
        try:
            target_id  = int(args[0])
            multiplier = float(args[1])
        except ValueError:
            await update.message.reply_text("Usage: /limit <user_id> <multiplier>")
            return

        cfg["user_limit_multipliers"][str(target_id)] = multiplier
        save_config(cfg)

        try:
            await context.bot.send_message(
                chat_id=target_id,
                text=f"Your usage limit has been set to {multiplier}x by an admin."
            )
        except Exception:
            pass

        await update.message.reply_text(f"User {target_id} limit set to {multiplier}x")

    elif len(args) == 1:
        try:
            multiplier = float(args[0])
        except ValueError:
            await update.message.reply_text("Usage: /limit <multiplier>")
            return

        cfg["user_limit_multipliers"]["global"] = multiplier
        save_config(cfg)
        await update.message.reply_text(f"Global limit multiplier set to {multiplier}x")
    else:
        await update.message.reply_text(
            "Usage:\n"
            "/limit <multiplier> — global\n"
            "/limit <user_id> <multiplier> — specific user"
        )


# ── /stats ────────────────────────────────────────────────────────────────────
async def stats_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not _require_admin(uid):
        return

    total_users    = len(_usage)
    total_msgs     = sum(len([t for t in d.get("messages", []) if t > _window()]) for d in _usage.values())
    total_searches = sum(len([t for t in d.get("searches", []) if t > _window()]) for d in _usage.values())
    total_images   = sum(len([t for t in d.get("images",   []) if t > _window()]) for d in _usage.values())

    cfg    = get_config()
    banned = len(cfg.get("banned_users", []))

    await update.message.reply_text(
        "Usage Stats (last hour)\n\n"
        f"Active users: {total_users}\n"
        f"Messages: {total_msgs}\n"
        f"Searches: {total_searches}\n"
        f"Images: {total_images}\n"
        f"Banned users: {banned}\n\n"
        f"Gemini Keys: {len(cfg.get('gemini_keys', []))}\n"
        f"Grok Keys: {len(cfg.get('grok_keys', []))}\n"
        f"Mistral Keys: {len(cfg.get('mistral_keys', []))}"
    )


# ── /addkey ───────────────────────────────────────────────────────────────────
async def addkey_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not _require_admin(uid):
        await update.message.reply_text("Admin access required.")
        return

    args = context.args
    if len(args) < 2:
        await update.message.reply_text("Usage: /addkey <gemini|grok|mistral> <API_KEY>")
        return

    provider = args[0].lower()
    key      = args[1].strip()
    cfg      = get_config()

    key_map = {
        "gemini":  "gemini_keys",
        "grok":    "grok_keys",
        "mistral": "mistral_keys",
    }

    if provider not in key_map:
        await update.message.reply_text("Unknown provider. Use: gemini, grok, or mistral")
        return

    field = key_map[provider]
    if key not in cfg[field]:
        cfg[field].append(key)
        save_config(cfg)
        await update.message.reply_text(
            f"{provider.capitalize()} key added. Total {provider} keys: {len(cfg[field])}"
        )
    else:
        await update.message.reply_text("Key already exists.")

    # Delete message to keep key secret
    try:
        await update.message.delete()
    except Exception:
        pass


# ── /delkey ───────────────────────────────────────────────────────────────────
async def delkey_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Delete an API key by provider and index (1-based)."""
    uid = update.effective_user.id
    if not _require_admin(uid):
        await update.message.reply_text("Admin access required.")
        return

    args = context.args
    if len(args) < 2:
        # Show current keys with indices for easy deletion
        cfg = get_config()
        lines = ["API Keys (use /delkey <provider> <index> to delete)\n"]
        for provider, field in [("gemini", "gemini_keys"), ("grok", "grok_keys"), ("mistral", "mistral_keys")]:
            keys = cfg.get(field, [])
            if keys:
                lines.append(f"{provider.capitalize()} keys:")
                for i, k in enumerate(keys, 1):
                    lines.append(f"  {i}. ...{k[-6:]}")
            else:
                lines.append(f"{provider.capitalize()} keys: none")
        await update.message.reply_text("\n".join(lines))
        return

    provider = args[0].lower()
    key_map = {
        "gemini":  "gemini_keys",
        "grok":    "grok_keys",
        "mistral": "mistral_keys",
    }

    if provider not in key_map:
        await update.message.reply_text("Unknown provider. Use: gemini, grok, or mistral")
        return

    try:
        index = int(args[1]) - 1  # convert to 0-based
    except ValueError:
        await update.message.reply_text("Index must be a number.")
        return

    cfg   = get_config()
    field = key_map[provider]
    keys  = cfg.get(field, [])

    if index < 0 or index >= len(keys):
        await update.message.reply_text(
            f"Invalid index. {provider.capitalize()} has {len(keys)} key(s). "
            f"Use /delkey {provider} to see them."
        )
        return

    removed = keys.pop(index)
    cfg[field] = keys
    save_config(cfg)
    await update.message.reply_text(
        f"{provider.capitalize()} key ...{removed[-6:]} deleted. "
        f"Remaining {provider} keys: {len(keys)}"
    )


# ── Callback from admin buttons ───────────────────────────────────────────────
async def handle_admin_callback(update, context, data: str):
    query  = update.callback_query
    cfg    = get_config()
    action = data.split(":")[1]

    if action == "stats":
        await query.edit_message_text("Use /stats for live stats.")

    elif action == "keys":
        lines = ["API Keys\n"]
        for provider, field in [("Gemini", "gemini_keys"), ("Grok", "grok_keys"), ("Mistral", "mistral_keys")]:
            keys = cfg.get(field, [])
            if keys:
                lines.append(f"{provider}: {len(keys)} key(s)")
                for i, k in enumerate(keys, 1):
                    lines.append(f"  {i}. ...{k[-6:]}")
            else:
                lines.append(f"{provider}: no keys")
        lines.append("\nUse /addkey <provider> <key> to add.")
        lines.append("Use /delkey <provider> <index> to delete.")
        await query.edit_message_text("\n".join(lines))

    elif action == "bans":
        bans = cfg.get("banned_users", [])
        text = "Banned Users\n\n"
        text += "\n".join([str(b) for b in bans]) if bans else "No banned users"
        await query.edit_message_text(text)

    elif action == "limits":
        limits = cfg.get("limits", {})
        lines = ["Current Limits (per hour)\n"]
        for tier in ("lite", "flash", "pro"):
            lim = limits.get(tier, {})
            lines.append(
                f"{tier.capitalize()}: "
                f"msgs={lim.get('messages','?')}, "
                f"imgs={lim.get('images','?')}, "
                f"searches={lim.get('searches','?')}"
            )
        lines.append("\nUse /limit <multiplier> to adjust globally.")
        await query.edit_message_text("\n".join(lines))
