"""
VoidAI v2 — Command handlers
FIX: Removed "VoidAI v2" badge from all replies.
     Plain text throughout — no markdown parse_mode, no ** stars visible.
     Web search results use plain text formatting.
"""

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from telegram.constants import ChatAction

from config import is_banned
from core.session import (
    get_model, set_model, reset_session, get_voice, set_voice, get_history, add_to_history
)
from core.limiter import check_limit, record_usage
from core.ai_provider import ask_ai
from core.search import web_search, format_search_for_user
from core.voice import INDIAN_VOICES, text_to_speech, clean_for_tts

logger = logging.getLogger(__name__)

MODEL_LABELS = {
    "lite":  ("Void Lite",  "Basic answering — fast & efficient"),
    "flash": ("Void Flash", "Powered by Gemini 2.0 Flash"),
    "pro":   ("Void Pro",   "Web-augmented answers — most powerful"),
}


async def start_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    name  = update.effective_user.first_name
    uid   = update.effective_user.id
    model = get_model(uid)
    label = MODEL_LABELS[model][0]

    await update.message.reply_text(
        f"Hey {name}! Welcome to VoidAI.\n\n"
        f"Current mode: {label}\n\n"
        "Commands:\n"
        "/switch — Change AI model\n"
        "/web <query> — Search the web\n"
        "/voicereply — Toggle voice replies\n"
        "/new — Start fresh chat\n"
        "/help — All features\n\n"
        "Just send a message and I'll respond!"
    )


async def help_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "VoidAI — Command Guide\n\n"
        "Models:\n"
        "  Void Lite — Fast Q&A, no web\n"
        "  Void Flash — Gemini 2.0 powered\n"
        "  Void Pro — Web-enriched answers\n\n"
        "Commands:\n"
        "/start — Welcome screen\n"
        "/switch — Switch AI model\n"
        "/new — Clear chat history\n"
        "/web <query> — Web search\n"
        "/summarize — Summarize replied msg\n"
        "/voicereply — Toggle voice mode\n"
        "/help — This menu\n\n"
        "Images:\n"
        "Send any image and I'll analyze it.\n"
        "Pro mode also searches the web.\n\n"
        "Voice Mode:\n"
        "Replies sent as audio + text caption.\n"
        "Choose from Indian voices."
    )


async def new_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    reset_session(uid)
    await update.message.reply_text("Chat cleared. Fresh start.")


async def switch_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid     = update.effective_user.id
    current = get_model(uid)

    buttons = []
    for key, (label, desc) in MODEL_LABELS.items():
        tick = " ✅" if key == current else ""
        buttons.append([InlineKeyboardButton(f"{label}{tick}", callback_data=f"switch:{key}")])

    await update.message.reply_text(
        "Select AI Model:\n\n"
        "Void Lite — Basic answering\n"
        "Void Flash — Gemini 2.0 powered\n"
        "Void Pro — Web-augmented AI",
        reply_markup=InlineKeyboardMarkup(buttons),
    )


async def summarize_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid     = update.effective_user.id
    replied = update.message.reply_to_message

    if not replied or not replied.text:
        await update.message.reply_text("Reply to a message and then use /summarize to summarize it.")
        return

    if is_banned(uid):
        return

    await update.message.chat.send_action(ChatAction.TYPING)

    summary = await ask_ai(
        prompt=f"Summarize this in 2-3 lines only:\n\n{replied.text}",
        history=[],
    )

    await update.message.reply_text(summary)


async def web_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid   = update.effective_user.id
    model = get_model(uid)
    query = " ".join(context.args) if context.args else ""

    if not query:
        await update.message.reply_text("Usage: /web your search query")
        return

    if is_banned(uid):
        return

    if not check_limit(uid, model, "searches"):
        await update.message.reply_text("Search limit reached for this hour. Limit resets every 60 minutes.")
        return

    record_usage(uid, "searches")
    await update.message.chat.send_action(ChatAction.TYPING)

    results = await web_search(query, max_results=5)
    text    = format_search_for_user(query, results)

    await update.message.reply_text(text, disable_web_page_preview=False)


async def voicereply_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid             = update.effective_user.id
    voice_on, current_voice = get_voice(uid)

    if context.args and context.args[0].lower() == "off":
        set_voice(uid, False)
        await update.message.reply_text("Voice replies disabled. I'll respond with text only now.")
        return

    buttons = []
    for display, code in INDIAN_VOICES.items():
        tick = " ✅" if code == current_voice else ""
        buttons.append([InlineKeyboardButton(f"{display}{tick}", callback_data=f"voice:{code}")])

    state = "ON" if voice_on else "OFF"
    await update.message.reply_text(
        f"Voice Reply — {state}\n\nChoose your preferred Indian voice:\n(Use /voicereply off to disable)",
        reply_markup=InlineKeyboardMarkup(buttons),
    )
