"""
VoidAI v2 — Web search (DuckDuckGo, no API key needed)
FIX: Plain text output (no markdown **bold**), async-safe via to_thread.
"""

import asyncio, logging

logger = logging.getLogger(__name__)

MAX_RESULTS = 5


def _ddgs_text_sync(query: str, max_results: int) -> list:
    """Blocking DDG search — must be called via asyncio.to_thread."""
    try:
        from duckduckgo_search import DDGS
        with DDGS() as ddgs:
            results = list(ddgs.text(
                query,
                max_results=max_results,
                safesearch="moderate",
            ))
        return results or []
    except Exception as e:
        logger.warning("DuckDuckGo search error: %s", e)
        return []


async def web_search(query: str, max_results: int = MAX_RESULTS) -> list:
    """Async-safe web search. Returns list of {title, href, body}."""
    results = await asyncio.to_thread(_ddgs_text_sync, query, max_results)
    if not results:
        await asyncio.sleep(2)
        results = await asyncio.to_thread(_ddgs_text_sync, query, max_results)
    return results


def format_search_results(results: list) -> str:
    """Plain summary for AI context (token-efficient)."""
    if not results:
        return "No results found."
    lines = []
    for i, r in enumerate(results, 1):
        title = r.get("title", "")
        body  = r.get("body", "")[:300]
        lines.append(f"{i}. {title}: {body}")
    return "\n".join(lines)


def format_search_for_user(query: str, results: list) -> str:
    """Plain text result for /web command."""
    if not results:
        return f"No results found for: {query}\n\nTry a shorter or different query."

    lines = [f"Web Results for: {query}\n"]
    for i, r in enumerate(results, 1):
        title = r.get("title", "Untitled")
        body  = r.get("body", "")[:250]
        url   = r.get("href", "")
        lines.append(f"{i}. {title}\n{body}\n{url}\n")
    return "\n".join(lines)
