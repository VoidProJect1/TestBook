"""
VoidAI v2 — Image analysis
Downloads Telegram photo → base64 for Gemini vision.
FIX: Upload image to Telegra.ph (free public API) to get a public URL,
     then use DuckDuckGo image search with that URL for real reverse search.
     Falls back to caption-based search if upload fails.
"""

import asyncio, base64, httpx, logging

logger = logging.getLogger(__name__)


async def download_image_b64(file_url: str) -> str | None:
    """Download a Telegram file URL and return base64-encoded bytes."""
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.get(file_url)
        r.raise_for_status()
        return base64.b64encode(r.content).decode()
    except Exception as e:
        logger.warning("Image download error (%s): %s", file_url[:60], e)
        return None


async def upload_to_telegraph(image_bytes: bytes) -> str | None:
    """Upload image bytes to Telegra.ph and return public URL."""
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.post(
                "https://telegra.ph/upload",
                files={"file": ("image.jpg", image_bytes, "image/jpeg")},
            )
        if r.status_code == 200:
            data = r.json()
            if isinstance(data, list) and data:
                path = data[0].get("src", "")
                if path:
                    return "https://telegra.ph" + path
    except Exception as e:
        logger.warning("Telegraph upload error: %s", e)
    return None


def _ddgs_text_sync(query: str, max_results: int) -> list:
    """Blocking DDG text search — run via asyncio.to_thread."""
    try:
        from duckduckgo_search import DDGS
        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=max_results, safesearch="moderate"))
        return results or []
    except Exception as e:
        logger.warning("DDG search error: %s", e)
        return []


async def reverse_image_search(keyword_or_b64: str, max_results: int = 3, image_bytes: bytes | None = None) -> list:
    """
    Reverse image search.
    If image_bytes provided: uploads to Telegra.ph then searches via that URL.
    Falls back to keyword-based text search.
    """
    # Try real reverse search via Telegraph URL
    if image_bytes:
        pub_url = await upload_to_telegraph(image_bytes)
        if pub_url:
            results = await asyncio.to_thread(_ddgs_text_sync, pub_url, max_results)
            if results:
                return results

    # Fallback: text search using caption/keyword
    if not keyword_or_b64 or len(keyword_or_b64) < 3:
        return []
    # Don't pass base64 data as a query — truncate to first 200 chars if it's text
    query = keyword_or_b64[:200] if len(keyword_or_b64) > 200 else keyword_or_b64
    return await asyncio.to_thread(_ddgs_text_sync, query, max_results)


def summarise_image_search(results: list) -> str:
    if not results:
        return ""
    parts = []
    for r in results:
        title = r.get("title", "")
        body  = r.get("body", "")[:150]
        if title:
            parts.append(f"{title}: {body}")
    return "Related web context: " + " | ".join(parts)[:500]
