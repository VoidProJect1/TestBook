"""
VoidAI v2 — AI Provider
FIX: _failed is per-call (429 doesn't permanently blacklist keys).
     Only 403 (invalid key) permanently disables a key.
     Proper error message when no keys configured.
"""

import httpx, logging, base64
from config import get_config

logger = logging.getLogger(__name__)

GEMINI_MODELS = [
    "gemini-2.0-flash",
    "gemini-2.0-flash-lite",
    "gemini-1.5-flash",
    "gemini-1.5-flash-8b",
]

GEMINI_BASE  = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
GROK_BASE    = "https://api.x.ai/v1/chat/completions"
MISTRAL_BASE = "https://api.mistral.ai/v1/chat/completions"

# Only permanently-dead keys (403 invalid) stay here across calls
_dead_keys: set = set()


def _detect_mime(b64: str) -> str:
    try:
        raw = base64.b64decode(b64[:16])
        if raw[:4] == b"\x89PNG":
            return "image/png"
        if raw[:3] == b"\xff\xd8\xff":
            return "image/jpeg"
        if raw[:4] == b"RIFF":
            return "image/webp"
    except Exception:
        pass
    return "image/jpeg"


async def _try_gemini(prompt, system, history, image_b64):
    cfg  = get_config()
    keys = cfg.get("gemini_keys", [])
    if not keys:
        return None

    contents = _build_gemini_contents(history, prompt, image_b64)
    sys_inst = {"parts": [{"text": system}]} if system else None

    for model in GEMINI_MODELS:
        for key in keys:
            tag = f"gemini:{key[:8]}:{model}"
            if tag in _dead_keys:
                continue
            url  = GEMINI_BASE.format(model=model) + f"?key={key}"
            body = {
                "contents": contents,
                "generationConfig": {"maxOutputTokens": 800, "temperature": 0.7},
            }
            if sys_inst:
                body["systemInstruction"] = sys_inst
            try:
                async with httpx.AsyncClient(timeout=30) as client:
                    r = await client.post(url, json=body)
                if r.status_code == 403:
                    logger.warning("Gemini %s key=%s: 403 invalid", model, key[:8])
                    _dead_keys.add(tag)
                    continue
                if r.status_code == 429:
                    logger.warning("Gemini %s key=%s: 429 rate limit", model, key[:8])
                    continue
                if r.status_code != 200:
                    logger.warning("Gemini %s HTTP %s", model, r.status_code)
                    continue
                data = r.json()
                cands = data.get("candidates", [])
                if not cands:
                    continue
                parts = cands[0].get("content", {}).get("parts", [])
                if not parts:
                    continue
                text = parts[0].get("text", "").strip()
                if text:
                    return text
            except Exception as e:
                logger.warning("Gemini error (%s): %s", tag, e)
    return None


def _build_gemini_contents(history, prompt, image_b64):
    contents = []
    for msg in history[-20:]:
        role = "user" if msg["role"] == "user" else "model"
        contents.append({"role": role, "parts": [{"text": msg["content"]}]})
    parts = []
    if image_b64:
        mime = _detect_mime(image_b64)
        parts.append({"inlineData": {"mimeType": mime, "data": image_b64}})
    parts.append({"text": prompt})
    contents.append({"role": "user", "parts": parts})
    return contents


async def _try_grok(prompt, system, history):
    cfg  = get_config()
    keys = cfg.get("grok_keys", [])
    if not keys:
        return None

    messages = _build_openai_messages(system, history, prompt)
    for key in keys:
        tag = f"grok:{key[:8]}"
        if tag in _dead_keys:
            continue
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                r = await client.post(
                    GROK_BASE,
                    headers={"Authorization": f"Bearer {key}"},
                    json={"model": "grok-2-latest", "messages": messages, "max_tokens": 800},
                )
            if r.status_code == 403:
                _dead_keys.add(tag)
                continue
            if r.status_code == 429:
                continue
            if r.status_code != 200:
                logger.warning("Grok HTTP %s", r.status_code)
                continue
            text = r.json()["choices"][0]["message"]["content"].strip()
            if text:
                return text
        except Exception as e:
            logger.warning("Grok error: %s", e)
    return None


async def _try_mistral(prompt, system, history):
    cfg  = get_config()
    keys = cfg.get("mistral_keys", [])
    if not keys:
        return None

    messages = _build_openai_messages(system, history, prompt)
    for key in keys:
        tag = f"mistral:{key[:8]}"
        if tag in _dead_keys:
            continue
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                r = await client.post(
                    MISTRAL_BASE,
                    headers={"Authorization": f"Bearer {key}"},
                    json={"model": "mistral-small-latest", "messages": messages, "max_tokens": 800},
                )
            if r.status_code == 403:
                _dead_keys.add(tag)
                continue
            if r.status_code == 429:
                continue
            if r.status_code != 200:
                logger.warning("Mistral HTTP %s", r.status_code)
                continue
            text = r.json()["choices"][0]["message"]["content"].strip()
            if text:
                return text
        except Exception as e:
            logger.warning("Mistral error: %s", e)
    return None


def _build_openai_messages(system, history, prompt):
    msgs = []
    if system:
        msgs.append({"role": "system", "content": system})
    for m in history[-20:]:
        msgs.append({"role": m["role"], "content": m["content"]})
    msgs.append({"role": "user", "content": prompt})
    return msgs


VOID_SYSTEM = (
    "You are VoidAI, an advanced AI assistant. "
    "Be concise, direct, and helpful. Never mention other AI names. "
    "Keep answers short unless deep explanation is needed. "
    "Do not pad responses."
)


async def ask_ai(prompt, history=None, image_b64=None, extra_context=None):
    history = history or []
    system  = VOID_SYSTEM
    if extra_context:
        system += f"\n\nContext from web/image search:\n{extra_context}"

    result = await _try_gemini(prompt, system, history, image_b64)
    if result:
        return result

    result = await _try_grok(prompt, system, history)
    if result:
        return result

    result = await _try_mistral(prompt, system, history)
    if result:
        return result

    cfg = get_config()
    if not any([cfg.get("gemini_keys"), cfg.get("grok_keys"), cfg.get("mistral_keys")]):
        return "No API keys configured. Ask an admin to add keys with /addkey."
    return "All AI providers are temporarily unavailable. Please try again in a moment."
