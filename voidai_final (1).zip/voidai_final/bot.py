"""
VoidAI — Single-file Telegram bot
Built on proven working patterns (requests + threading, HTML parse mode).
Supports: Gemini, Grok, Mistral (auto-rotation)
Features: Web search, Image analysis (vision AI), Voice replies (edge-tts),
          Admin panel with add/delete keys, ban/unban, usage stats, per-user limits.
"""

import base64
import html
import json
import os
import re
import threading
import time
from typing import Dict, List, Optional, Tuple

import requests
from bs4 import BeautifulSoup

# =============================================================================
# CONFIG FILE  (void_config.json lives next to this file)
# =============================================================================
CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "void_config.json")

BOT_TOKEN        = "PASTE_YOUR_TELEGRAM_BOT_TOKEN"   # ← replace
BOOTSTRAP_ADMIN  = 5479881365                         # ← replace with your Telegram user ID

_CFG_DEFAULTS = {
    "admin_ids":              [BOOTSTRAP_ADMIN],
    "gemini_keys":            [],
    "grok_keys":              [],
    "mistral_keys":           [],
    "banned_users":           [],
    "user_limit_multipliers": {},   # {str(user_id): float}
    "limits": {
        "lite":  {"messages": 200, "images": 10, "searches": 50},
        "flash": {"messages": 100, "images": 10, "searches": 50},
        "pro":   {"messages":  50, "images": 10, "searches": 50},
    },
}

def _load_cfg() -> dict:
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE) as f:
                data = json.load(f)
            for k, v in _CFG_DEFAULTS.items():
                if k not in data:
                    data[k] = v
            if BOOTSTRAP_ADMIN not in data["admin_ids"]:
                data["admin_ids"].append(BOOTSTRAP_ADMIN)
            return data
        except Exception:
            pass
    cfg = dict(_CFG_DEFAULTS)
    _save_cfg(cfg)
    return cfg

def _save_cfg(cfg: dict):
    with open(CONFIG_FILE, "w") as f:
        json.dump(cfg, f, indent=2)

def get_cfg() -> dict:   return _load_cfg()
def save_cfg(cfg: dict): _save_cfg(cfg)
def is_admin(uid: int)  -> bool: return uid == BOOTSTRAP_ADMIN or uid in _load_cfg()["admin_ids"]
def is_banned(uid: int) -> bool: return uid in _load_cfg()["banned_users"]

# =============================================================================
# SESSION  (in-memory per user)
# =============================================================================
_sessions: Dict[int, dict] = {}
_usage:    Dict[int, dict] = {}   # {uid: {action: [timestamps]}}

def _default_sess() -> dict:
    return {
        "model":      "flash",          # lite | flash | pro
        "history":    [],               # [{role, content}]
        "voice_on":   False,
        "voice_name": "hi-IN-SwaraNeural",
    }

def get_sess(uid: int) -> dict:
    if uid not in _sessions:
        _sessions[uid] = _default_sess()
    return _sessions[uid]

def reset_sess(uid: int): _sessions[uid] = _default_sess()

def add_history(uid: int, role: str, content: str):
    h = get_sess(uid)["history"]
    h.append({"role": role, "content": content})
    if len(h) > 30:
        get_sess(uid)["history"] = h[-30:]

def get_history(uid: int) -> list: return get_sess(uid)["history"]
def get_model(uid: int)   -> str:  return get_sess(uid)["model"]

def set_model(uid: int, model: str):
    if model in ("lite", "flash", "pro"):
        get_sess(uid)["model"] = model

def get_voice(uid: int) -> Tuple[bool, str]:
    s = get_sess(uid)
    return s["voice_on"], s["voice_name"]

def set_voice(uid: int, on: bool, name: str = None):
    s = get_sess(uid)
    s["voice_on"] = on
    if name:
        s["voice_name"] = name

# =============================================================================
# RATE LIMITER
# =============================================================================
def _window(): return time.time() - 3600

def _get_limit(uid: int, model: str, action: str) -> int:
    cfg  = get_cfg()
    base = cfg["limits"].get(model, {}).get(action, 50)
    mult = float(cfg["user_limit_multipliers"].get(str(uid), cfg["user_limit_multipliers"].get("global", 1)))
    return int(base * mult)

def check_limit(uid: int, action: str = "messages") -> bool:
    model  = get_model(uid)
    stamps = [t for t in _usage.get(uid, {}).get(action, []) if t > _window()]
    _usage.setdefault(uid, {})[action] = stamps
    return len(stamps) < _get_limit(uid, model, action)

def record_usage(uid: int, action: str = "messages"):
    _usage.setdefault(uid, {}).setdefault(action, []).append(time.time())

def usage_stats(uid: int) -> dict:
    model = get_model(uid)
    return {
        a: {
            "used":  len([t for t in _usage.get(uid, {}).get(a, []) if t > _window()]),
            "limit": _get_limit(uid, model, a),
        }
        for a in ("messages", "images", "searches")
    }

# =============================================================================
# DEAD KEY TRACKING  (only 403 = truly invalid)
# =============================================================================
_dead_keys: set = set()

# =============================================================================
# HTTP SESSION
# =============================================================================
HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"
    )
}
http = requests.Session()
http.headers.update(HEADERS)

TG_API = f"https://api.telegram.org/bot{BOT_TOKEN}"

# =============================================================================
# TELEGRAM HELPERS
# =============================================================================
def esc(t: str) -> str: return html.escape(t or "", quote=False)

def tg(method: str, data: dict = None, files=None, timeout=30):
    url = f"{TG_API}/{method}"
    try:
        if files:
            r = http.post(url, data=data or {}, files=files, timeout=timeout)
        else:
            r = http.post(url, data=data or {}, timeout=timeout)
        return r.json()
    except Exception as e:
        print(f"[TG] {method} error: {e}")
        return {}

def send_msg(chat_id: int, text: str, markup: dict = None) -> int:
    payload = {
        "chat_id":                  chat_id,
        "text":                     text,
        "parse_mode":               "HTML",
        "disable_web_page_preview": True,
    }
    if markup:
        payload["reply_markup"] = json.dumps(markup)
    res = tg("sendMessage", payload, timeout=20)
    return res.get("result", {}).get("message_id", 0)

def edit_msg(chat_id: int, msg_id: int, text: str, markup: dict = None):
    payload = {
        "chat_id":                  chat_id,
        "message_id":               msg_id,
        "text":                     text,
        "parse_mode":               "HTML",
        "disable_web_page_preview": True,
    }
    if markup:
        payload["reply_markup"] = json.dumps(markup)
    tg("editMessageText", payload, timeout=20)

def answer_cb(cb_id: str, text: str = ""):
    tg("answerCallbackQuery", {"callback_query_id": cb_id, "text": text}, timeout=10)

def send_typing(chat_id: int):
    tg("sendChatAction", {"chat_id": chat_id, "action": "typing"}, timeout=5)

def typing_loop(chat_id: int, stop: threading.Event):
    while not stop.is_set():
        try: send_typing(chat_id)
        except Exception: pass
        stop.wait(4.0)

def start_typing(chat_id: int) -> Tuple[int, threading.Event]:
    """Send a placeholder message and start typing indicator. Returns (msg_id, stop_event)."""
    stop = threading.Event()
    threading.Thread(target=typing_loop, args=(chat_id, stop), daemon=True).start()
    msg_id = send_msg(chat_id, "⏳ Processing...")
    return msg_id, stop

def get_updates(offset=None):
    params = {"timeout": 30}
    if offset is not None:
        params["offset"] = offset
    try:
        r = http.get(f"{TG_API}/getUpdates", params=params, timeout=40)
        r.raise_for_status()
        return r.json().get("result", [])
    except Exception as e:
        print(f"[TG] getUpdates error: {e}")
        return []

def split_and_send(chat_id: int, text: str, markup: dict = None, limit: int = 3900):
    """Split long text and send as multiple messages."""
    parts = []
    while len(text) > limit:
        cut = text.rfind("\n", 0, limit)
        if cut == -1: cut = limit
        parts.append(text[:cut])
        text = text[cut:].lstrip("\n")
    if text: parts.append(text)
    for i, part in enumerate(parts):
        send_msg(chat_id, part, markup if i == len(parts) - 1 else None)

# =============================================================================
# WEB SEARCH
# Priority 1: SearXNG  (self-hosted, unlimited, fastest)
# Priority 2: DDG Lite (direct HTTP POST, plain text)
# Priority 3: duckduckgo-search library (last resort)
# =============================================================================

# ── SearXNG config ────────────────────────────────────────────────────────────
# Set this to your SearXNG instance URL after installing it.
# Leave as empty string "" to skip SearXNG and go straight to DDG.
SEARXNG_URL = "http://127.0.0.1:8080"   # change port if you used a different one

_search_cache: Dict[str, dict] = {}

def _cache_get(key: str):
    item = _search_cache.get(key)
    if not item: return None
    if time.time() - item["ts"] > 600:
        _search_cache.pop(key, None)
        return None
    return item["value"]

def _cache_set(key: str, value):
    _search_cache[key] = {"ts": time.time(), "value": value}


def _searxng(query: str, max_results: int) -> List[Dict]:
    """
    Query your self-hosted SearXNG instance.
    Returns results from multiple engines (Google, Bing, DDG, etc.) combined.
    Completely unlimited — it is YOUR server.
    """
    if not SEARXNG_URL:
        return []
    try:
        r = http.get(
            f"{SEARXNG_URL}/search",
            params={
                "q":       query,
                "format":  "json",
                "engines": "google,bing,duckduckgo,brave",
                "language":"en",
            },
            timeout=10,
        )
        r.raise_for_status()
        data = r.json()
        results = []
        for item in data.get("results", [])[:max_results]:
            results.append({
                "title":   item.get("title", ""),
                "link":    item.get("url", ""),
                "snippet": item.get("content", ""),
            })
        return results
    except Exception as e:
        print(f"[SearXNG] error: {e}")
        return []


def _ddg_lite(query: str, max_results: int) -> List[Dict]:
    """
    DDG Lite — https://lite.duckduckgo.com/lite/
    Pure HTML, no JS, no AI filter. High rate limit, fast.
    """
    try:
        r = http.post(
            "https://lite.duckduckgo.com/lite/",
            data={"q": query},
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            timeout=15,
        )
        r.raise_for_status()
        soup = BeautifulSoup(r.text, "html.parser")
        results = []
        rows = soup.find_all("tr")
        i = 0
        while i < len(rows) and len(results) < max_results:
            row = rows[i]
            link_tag = row.find("a", class_="result-link")
            if link_tag:
                title   = link_tag.get_text(" ", strip=True)
                url     = link_tag.get("href", "")
                snippet = ""
                if i + 1 < len(rows):
                    snip_td = rows[i + 1].find("td", class_="result-snippet")
                    if snip_td:
                        snippet = re.sub(r"\s+", " ", snip_td.get_text(" ", strip=True)).strip()
                if title and url:
                    results.append({"title": title, "link": url, "snippet": snippet})
            i += 1
        return results
    except Exception as e:
        print(f"[DDG-Lite] error: {e}")
        return []


def _ddg_library(query: str, max_results: int) -> List[Dict]:
    """Last resort — duckduckgo-search library."""
    try:
        from duckduckgo_search import DDGS
        with DDGS() as ddgs:
            raw = list(ddgs.text(query, max_results=max_results, safesearch="moderate"))
        return [
            {"title": r.get("title",""), "link": r.get("href",""), "snippet": r.get("body","")}
            for r in raw
        ]
    except Exception as e:
        print(f"[DDG-Library] error: {e}")
        return []


def ddg_search(query: str, max_results: int = 4) -> List[Dict]:
    """
    Search pipeline:
    1. SearXNG (self-hosted, unlimited) — if configured
    2. DDG Lite (fast, high limit)
    3. duckduckgo-search library (fallback)
    Results cached 10 minutes.
    """
    cache_key = f"search::{query.lower()}"
    cached = _cache_get(cache_key)
    if cached: return cached

    # 1. Try SearXNG first
    if SEARXNG_URL:
        results = _searxng(query, max_results)
        if results:
            _cache_set(cache_key, results)
            return results
        print("[Search] SearXNG failed, trying DDG Lite...")

    # 2. Try DDG Lite
    results = _ddg_lite(query, max_results)
    if results:
        _cache_set(cache_key, results)
        return results
    print("[Search] DDG Lite failed, trying library...")

    # 3. Last resort: library
    results = _ddg_library(query, max_results)
    if results:
        _cache_set(cache_key, results)
    return results
def format_context(query: str, results: List[Dict]) -> str:
    lines = [f"QUESTION: {query}", "", "WEB SEARCH RESULTS:"]
    for i, r in enumerate(results, 1):
        lines.append(f"{i}. {r.get('title', '')}")
        lines.append(f"   URL: {r.get('link', '')}")
        lines.append(f"   {r.get('snippet', '')}")
        lines.append("")
    return "\n".join(lines)

# =============================================================================
# AI PROVIDERS
# =============================================================================
GEMINI_MODELS = ["gemini-2.0-flash", "gemini-2.0-flash-lite", "gemini-1.5-flash"]
GEMINI_BASE   = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
GROK_BASE     = "https://api.x.ai/v1/chat/completions"
MISTRAL_BASE  = "https://api.mistral.ai/v1/chat/completions"

VOID_SYSTEM = (
    "You are VoidAI, a smart and helpful assistant. "
    "Be concise and direct. Never mention other AI product names. "
    "Answer clearly without unnecessary padding."
)

def _detect_mime(b64: str) -> str:
    try:
        raw = base64.b64decode(b64[:16])
        if raw[:4] == b"\x89PNG": return "image/png"
        if raw[:3] == b"\xff\xd8\xff": return "image/jpeg"
        if raw[:4] == b"RIFF": return "image/webp"
    except Exception: pass
    return "image/jpeg"

def _gemini_contents(history: list, prompt: str, image_b64: str = None) -> list:
    contents = []
    for m in history[-20:]:
        role = "user" if m["role"] == "user" else "model"
        contents.append({"role": role, "parts": [{"text": m["content"]}]})
    parts = []
    if image_b64:
        mime = _detect_mime(image_b64)
        parts.append({"inlineData": {"mimeType": mime, "data": image_b64}})
    parts.append({"text": prompt})
    contents.append({"role": "user", "parts": parts})
    return contents

def _openai_messages(system: str, history: list, prompt: str) -> list:
    msgs = [{"role": "system", "content": system}]
    for m in history[-20:]:
        msgs.append({"role": m["role"], "content": m["content"]})
    msgs.append({"role": "user", "content": prompt})
    return msgs

def _try_gemini(prompt: str, system: str, history: list, image_b64: str = None) -> Optional[str]:
    cfg  = get_cfg()
    keys = cfg.get("gemini_keys", [])
    if not keys: return None

    contents = _gemini_contents(history, prompt, image_b64)
    sys_inst = {"parts": [{"text": system}]}

    for model in GEMINI_MODELS:
        for key in keys:
            tag = f"gemini:{key[:8]}:{model}"
            if tag in _dead_keys: continue
            url  = GEMINI_BASE.format(model=model) + f"?key={key}"
            body = {
                "contents": contents,
                "systemInstruction": sys_inst,
                "generationConfig": {"maxOutputTokens": 800, "temperature": 0.7},
            }
            try:
                r = http.post(url, json=body, timeout=30)
                if r.status_code == 403:
                    _dead_keys.add(tag); continue
                if r.status_code == 429: continue
                if r.status_code != 200:
                    print(f"[Gemini] {model} HTTP {r.status_code}"); continue
                data  = r.json()
                cands = data.get("candidates", [])
                if not cands: continue
                parts = cands[0].get("content", {}).get("parts", [])
                if not parts: continue
                text = parts[0].get("text", "").strip()
                if text: return text
            except Exception as e:
                print(f"[Gemini] {tag}: {e}")
    return None

def _try_grok(prompt: str, system: str, history: list) -> Optional[str]:
    cfg  = get_cfg()
    keys = cfg.get("grok_keys", [])
    if not keys: return None

    msgs = _openai_messages(system, history, prompt)
    for key in keys:
        tag = f"grok:{key[:8]}"
        if tag in _dead_keys: continue
        try:
            r = http.post(
                GROK_BASE,
                headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                json={"model": "grok-2-latest", "messages": msgs, "max_tokens": 800},
                timeout=30,
            )
            if r.status_code == 403: _dead_keys.add(tag); continue
            if r.status_code == 429: continue
            if r.status_code != 200: print(f"[Grok] HTTP {r.status_code}"); continue
            text = r.json()["choices"][0]["message"]["content"].strip()
            if text: return text
        except Exception as e:
            print(f"[Grok] {tag}: {e}")
    return None

def _try_mistral(prompt: str, system: str, history: list, image_b64: str = None) -> Optional[str]:
    cfg  = get_cfg()
    keys = cfg.get("mistral_keys", [])
    if not keys: return None

    if image_b64:
        # Vision call
        msgs = [{
            "role": "user",
            "content": [
                {"type": "text",      "text": prompt},
                {"type": "image_url", "image_url": f"data:{_detect_mime(image_b64)};base64,{image_b64}"},
            ],
        }]
        model = "mistral-small-2506"
    else:
        msgs  = _openai_messages(system, history, prompt)
        model = "mistral-small-latest"

    for key in keys:
        tag = f"mistral:{key[:8]}"
        if tag in _dead_keys: continue
        try:
            r = http.post(
                MISTRAL_BASE,
                headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                json={"model": model, "messages": msgs, "max_tokens": 800},
                timeout=60,
            )
            if r.status_code == 403: _dead_keys.add(tag); continue
            if r.status_code == 429: continue
            if r.status_code != 200: print(f"[Mistral] HTTP {r.status_code}: {r.text[:200]}"); continue
            text = r.json()["choices"][0]["message"]["content"].strip()
            if text: return text
        except Exception as e:
            print(f"[Mistral] {tag}: {e}")
    return None

def ask_ai(prompt: str, history: list = None, image_b64: str = None, extra_context: str = None) -> str:
    history = history or []
    system  = VOID_SYSTEM
    if extra_context:
        system += f"\n\nWeb search context:\n{extra_context}"

    # For images: try Gemini vision first, then Mistral vision
    if image_b64:
        result = _try_gemini(prompt, system, history, image_b64)
        if result: return result
        result = _try_mistral(prompt, system, history, image_b64)
        if result: return result
        # Gemini without image as last fallback
        result = _try_grok(prompt, system, history)
        if result: return result
    else:
        result = _try_gemini(prompt, system, history)
        if result: return result
        result = _try_grok(prompt, system, history)
        if result: return result
        result = _try_mistral(prompt, system, history)
        if result: return result

    cfg = get_cfg()
    if not any([cfg.get("gemini_keys"), cfg.get("grok_keys"), cfg.get("mistral_keys")]):
        return "No API keys configured. Admin: use /addkey to add keys."
    return "All AI providers are temporarily unavailable. Please try again in a moment."

# =============================================================================
# IMAGE DOWNLOAD + TELEGRAPH UPLOAD
# =============================================================================
def download_tg_image(file_id: str) -> Optional[bytes]:
    res = tg("getFile", {"file_id": file_id})
    if not res.get("ok"): return None
    file_path = res["result"]["file_path"]
    file_url  = f"https://api.telegram.org/file/bot{BOT_TOKEN}/{file_path}"
    try:
        r = http.get(file_url, timeout=40)
        r.raise_for_status()
        return r.content
    except Exception as e:
        print(f"[IMG] download error: {e}")
        return None

def upload_telegraph(img_bytes: bytes) -> Optional[str]:
    """Upload to Telegraph for reverse image search URL."""
    try:
        r = http.post(
            "https://telegra.ph/upload",
            files={"file": ("image.jpg", img_bytes, "image/jpeg")},
            timeout=20,
        )
        if r.status_code == 200:
            data = r.json()
            if isinstance(data, list) and data:
                path = data[0].get("src", "")
                if path: return "https://telegra.ph" + path
    except Exception as e:
        print(f"[Telegraph] upload error: {e}")
    return None

# =============================================================================
# VOICE  (edge-tts)
# =============================================================================
INDIAN_VOICES = {
    "Hindi Female (Swara)":   "hi-IN-SwaraNeural",
    "Hindi Male (Madhur)":    "hi-IN-MadhurNeural",
    "English Female (Neerja)":"en-IN-NeerjaNeural",
    "English Male (Prabhat)": "en-IN-PrabhatNeural",
    "Tamil Female (Pallavi)": "ta-IN-PallaviNeural",
    "Tamil Male (Valluvar)":  "ta-IN-ValluvarNeural",
    "Telugu Female (Shruti)": "te-IN-ShrutiNeural",
    "Telugu Male (Mohan)":    "te-IN-MohanNeural",
    "Kannada Female (Sapna)": "kn-IN-SapnaNeural",
    "Kannada Male (Gagan)":   "kn-IN-GaganNeural",
}

VOICE_CLEAN_RE = re.compile(
    "["
    u"\U0001F600-\U0001F64F"
    u"\U0001F300-\U0001F5FF"
    u"\U0001F680-\U0001F6FF"
    u"\U0001F1E0-\U0001F1FF"
    u"\U00002702-\U000027B0"
    u"\U000024C2-\U0001F251"
    u"\u2640-\u2642"
    u"\u2600-\u2B55"
    u"\ufe0f\u200d\u23cf\u23e9\u231a\u3030"
    "]+",
    flags=re.UNICODE,
)

def clean_for_tts(text: str) -> str:
    text = re.sub(r"\*+|_+|`+|#+|~+", "", text)
    text = re.sub(r"https?://\S+", "", text)
    text = re.sub(r"\[([^\]]+)\]\([^\)]+\)", r"\1", text)
    text = VOICE_CLEAN_RE.sub("", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:1200]

def tts_to_bytes(text: str, voice: str) -> Optional[bytes]:
    """Run edge-tts and return OGA audio bytes."""
    import asyncio, tempfile, edge_tts
    async def _run():
        tmp = tempfile.NamedTemporaryFile(suffix=".oga", delete=False)
        tmp.close()
        comm = edge_tts.Communicate(text, voice)
        await comm.save(tmp.name)
        return tmp.name
    try:
        loop = asyncio.new_event_loop()
        path = loop.run_until_complete(_run())
        loop.close()
        if os.path.getsize(path) < 100:
            os.unlink(path)
            return None
        with open(path, "rb") as f:
            data = f.read()
        os.unlink(path)
        return data
    except Exception as e:
        print(f"[TTS] error: {e}")
        return None

def send_voice_reply(chat_id: int, text: str, voice_name: str):
    clean  = clean_for_tts(text)
    audio  = tts_to_bytes(clean, voice_name)
    if audio:
        caption = text[:900] if len(text) <= 900 else text[:897] + "…"
        try:
            tg("sendVoice", {"chat_id": chat_id, "caption": caption}, files={"voice": ("voice.oga", audio, "audio/ogg")}, timeout=60)
            return
        except Exception as e:
            print(f"[Voice] send error: {e}")
    send_msg(chat_id, text)

# =============================================================================
# INLINE KEYBOARDS
# =============================================================================
def main_markup(uid: int) -> dict:
    model = get_model(uid)
    labels = {"lite": "Lite", "flash": "Flash", "pro": "Pro"}
    return {
        "inline_keyboard": [
            [
                {"text": f"Model: {labels[model]}", "callback_data": "open:switch"},
                {"text": "Voice", "callback_data": "open:voice"},
            ],
            [
                {"text": "New Chat", "callback_data": "cmd:new"},
                {"text": "Web Search", "callback_data": "open:webprompt"},
            ],
        ]
    }

def switch_markup(uid: int) -> dict:
    current = get_model(uid)
    rows = []
    for key, label in [("lite", "Void Lite — fast"), ("flash", "Void Flash — balanced"), ("pro", "Void Pro — web AI")]:
        tick = " ✅" if key == current else ""
        rows.append([{"text": f"{label}{tick}", "callback_data": f"switch:{key}"}])
    rows.append([{"text": "⬅️ Back", "callback_data": "open:main"}])
    return {"inline_keyboard": rows}

def voice_markup(uid: int) -> dict:
    voice_on, current = get_voice(uid)
    rows = []
    for display, code in list(INDIAN_VOICES.items())[:6]:
        tick = " ✅" if code == current else ""
        rows.append([{"text": f"{display}{tick}", "callback_data": f"voice:{code}"}])
    state_text = "Turn OFF Voice" if voice_on else "Turn ON Voice"
    rows.append([{"text": state_text, "callback_data": "voice:toggle"}])
    rows.append([{"text": "⬅️ Back", "callback_data": "open:main"}])
    return {"inline_keyboard": rows}

def admin_markup() -> dict:
    return {
        "inline_keyboard": [
            [{"text": "Manage Keys",   "callback_data": "admin:keys"}],
            [{"text": "Usage Stats",   "callback_data": "admin:stats"}],
            [{"text": "Banned Users",  "callback_data": "admin:bans"}],
            [{"text": "Rate Limits",   "callback_data": "admin:limits"}],
        ]
    }

# =============================================================================
# COMMAND HANDLERS
# =============================================================================
def handle_start(chat_id: int, uid: int, name: str):
    model   = get_model(uid)
    labels  = {"lite": "Void Lite", "flash": "Void Flash", "pro": "Void Pro"}
    text = (
        f"<b>Hey {esc(name)}! Welcome to VoidAI.</b>\n\n"
        f"Current mode: {labels[model]}\n\n"
        "Send any message and I'll answer.\n"
        "Send a photo for image analysis.\n\n"
        "<b>Commands:</b>\n"
        "/switch — Change AI model\n"
        "/new — Clear chat history\n"
        "/web query — Web search\n"
        "/voice — Toggle voice replies\n"
        "/help — All commands"
    )
    send_msg(chat_id, text, main_markup(uid))

def handle_help(chat_id: int):
    send_msg(chat_id,
        "<b>VoidAI — Commands</b>\n\n"
        "/start — Welcome\n"
        "/switch — Change model\n"
        "/new — Clear history\n"
        "/web query — Web search\n"
        "/voice — Voice reply settings\n"
        "/help — This menu\n\n"
        "<b>Models:</b>\n"
        "Void Lite — Fast answers\n"
        "Void Flash — Balanced\n"
        "Void Pro — Web-augmented\n\n"
        "<b>Send a photo</b> for AI image analysis.\n"
        "<b>Voice replies</b> available in Indian languages."
    )

def handle_new(chat_id: int, uid: int):
    reset_sess(uid)
    send_msg(chat_id, "Chat history cleared.")

def handle_switch(chat_id: int, uid: int):
    send_msg(chat_id, "Select AI model:", switch_markup(uid))

def handle_voice_cmd(chat_id: int, uid: int):
    voice_on, voice_name = get_voice(uid)
    state = "ON" if voice_on else "OFF"
    send_msg(chat_id, f"Voice replies: <b>{state}</b>\nSelect a voice:", voice_markup(uid))

def handle_web_cmd(chat_id: int, uid: int, query: str):
    if not query.strip():
        send_msg(chat_id, "Usage: /web your search query")
        return
    if not check_limit(uid, "searches"):
        send_msg(chat_id, "Search limit reached for this hour.")
        return
    record_usage(uid, "searches")
    handle_question(chat_id, uid, query, force_web=True)

# =============================================================================
# QUESTION HANDLER  (core logic)
# =============================================================================
def handle_question(chat_id: int, uid: int, text: str, force_web: bool = False):
    if not check_limit(uid, "messages"):
        send_msg(chat_id, "Message limit reached for this hour.")
        return
    record_usage(uid, "messages")

    msg_id, stop = start_typing(chat_id)
    try:
        model         = get_model(uid)
        extra_context = None

        # Web search for pro mode or /web command
        if model == "pro" or force_web:
            if check_limit(uid, "searches"):
                record_usage(uid, "searches")
                results = ddg_search(text, max_results=4)
                if results:
                    extra_context = format_context(text, results)

        answer = ask_ai(
            prompt=text,
            history=get_history(uid),
            extra_context=extra_context,
        )

        add_history(uid, "user",      text)
        add_history(uid, "assistant", answer)

        stop.set()
        voice_on, voice_name = get_voice(uid)
        if voice_on:
            tg("deleteMessage", {"chat_id": chat_id, "message_id": msg_id})
            send_voice_reply(chat_id, answer, voice_name)
        else:
            edit_msg(chat_id, msg_id, answer, main_markup(uid))

    except Exception as e:
        stop.set()
        edit_msg(chat_id, msg_id, f"Error: {esc(str(e))}")

# =============================================================================
# IMAGE HANDLER
# =============================================================================
def handle_image(chat_id: int, uid: int, photo_sizes: list, caption: str = ""):
    if not check_limit(uid, "images"):
        send_msg(chat_id, "Image analysis limit reached for this hour.")
        return
    record_usage(uid, "images")

    msg_id, stop = start_typing(chat_id)
    try:
        img_bytes = download_tg_image(photo_sizes[-1]["file_id"])
        if not img_bytes:
            stop.set()
            edit_msg(chat_id, msg_id, "Could not download image. Please try again.")
            return

        image_b64   = base64.b64encode(img_bytes).decode()
        prompt      = caption or "Describe this image in detail."
        extra_ctx   = None

        # Pro mode: reverse image search via Telegraph
        if get_model(uid) == "pro":
            pub_url = upload_telegraph(img_bytes)
            if pub_url:
                results = ddg_search(pub_url, max_results=3)
            else:
                results = ddg_search(prompt, max_results=3) if len(prompt) > 5 else []
            if results:
                extra_ctx = format_context(prompt, results)

        answer = ask_ai(
            prompt=prompt,
            history=get_history(uid),
            image_b64=image_b64,
            extra_context=extra_ctx,
        )

        add_history(uid, "user",      f"[Image] {prompt}")
        add_history(uid, "assistant", answer)

        stop.set()
        voice_on, voice_name = get_voice(uid)
        if voice_on:
            tg("deleteMessage", {"chat_id": chat_id, "message_id": msg_id})
            send_voice_reply(chat_id, answer, voice_name)
        else:
            edit_msg(chat_id, msg_id, f"<b>Image Analysis</b>\n\n{esc(answer)}", main_markup(uid))

    except Exception as e:
        stop.set()
        edit_msg(chat_id, msg_id, f"Image error: {esc(str(e))}")

# =============================================================================
# ADMIN HANDLERS
# =============================================================================
def handle_admin(chat_id: int, uid: int):
    if not is_admin(uid):
        send_msg(chat_id, "Admin access required.")
        return
    cfg = get_cfg()
    send_msg(chat_id,
        "<b>Admin Panel</b>\n\n"
        f"Gemini keys: {len(cfg.get('gemini_keys', []))}\n"
        f"Grok keys:   {len(cfg.get('grok_keys', []))}\n"
        f"Mistral keys:{len(cfg.get('mistral_keys', []))}\n"
        f"Admins:      {len(cfg.get('admin_ids', []))}\n"
        f"Banned:      {len(cfg.get('banned_users', []))}\n\n"
        "<b>Commands:</b>\n"
        "/addkey gemini|grok|mistral KEY\n"
        "/delkey gemini|grok|mistral INDEX\n"
        "/listkeys — show all keys (masked)\n"
        "/addadmin USER_ID\n"
        "/ban USER_ID\n"
        "/limit USER_ID MULTIPLIER\n"
        "/stats",
        admin_markup(),
    )

def handle_addkey(chat_id: int, uid: int, args: list):
    if not is_admin(uid):
        send_msg(chat_id, "Admin access required."); return
    if len(args) < 2:
        send_msg(chat_id, "Usage: /addkey gemini|grok|mistral YOUR_KEY"); return
    provider, key = args[0].lower(), args[1].strip()
    key_map = {"gemini": "gemini_keys", "grok": "grok_keys", "mistral": "mistral_keys"}
    if provider not in key_map:
        send_msg(chat_id, "Unknown provider. Use: gemini, grok, mistral"); return
    cfg   = get_cfg()
    field = key_map[provider]
    if key in cfg[field]:
        send_msg(chat_id, "Key already exists.")
    else:
        cfg[field].append(key)
        save_cfg(cfg)
        send_msg(chat_id, f"{provider.capitalize()} key added. Total: {len(cfg[field])}")
    tg("deleteMessage", {"chat_id": chat_id, "message_id": 0})  # best effort delete

def handle_delkey(chat_id: int, uid: int, args: list):
    if not is_admin(uid):
        send_msg(chat_id, "Admin access required."); return
    key_map = {"gemini": "gemini_keys", "grok": "grok_keys", "mistral": "mistral_keys"}
    if len(args) < 2:
        # Show list
        cfg = get_cfg()
        lines = ["<b>API Keys</b> (use /delkey provider index)\n"]
        for p, f in key_map.items():
            keys = cfg.get(f, [])
            lines.append(f"<b>{p.capitalize()}</b>: {len(keys)} key(s)")
            for i, k in enumerate(keys, 1):
                lines.append(f"  {i}. ...{k[-8:]}")
        send_msg(chat_id, "\n".join(lines)); return

    provider = args[0].lower()
    if provider not in key_map:
        send_msg(chat_id, "Unknown provider."); return
    try:
        index = int(args[1]) - 1
    except ValueError:
        send_msg(chat_id, "Index must be a number."); return
    cfg   = get_cfg()
    field = key_map[provider]
    keys  = cfg.get(field, [])
    if index < 0 or index >= len(keys):
        send_msg(chat_id, f"Invalid index. {provider} has {len(keys)} key(s)."); return
    removed = keys.pop(index)
    cfg[field] = keys
    save_cfg(cfg)
    send_msg(chat_id, f"Deleted {provider} key ...{removed[-8:]}. Remaining: {len(keys)}")

def handle_listkeys(chat_id: int, uid: int):
    if not is_admin(uid):
        send_msg(chat_id, "Admin access required."); return
    cfg = get_cfg()
    lines = ["<b>API Keys</b>\n"]
    for p, f in [("Gemini","gemini_keys"),("Grok","grok_keys"),("Mistral","mistral_keys")]:
        keys = cfg.get(f, [])
        lines.append(f"<b>{p}</b>: {len(keys)}")
        for i, k in enumerate(keys, 1):
            lines.append(f"  {i}. ...{k[-8:]}")
    send_msg(chat_id, "\n".join(lines))

def handle_addadmin(chat_id: int, uid: int, args: list):
    if not is_admin(uid):
        send_msg(chat_id, "Admin access required."); return
    if not args:
        send_msg(chat_id, "Usage: /addadmin USER_ID"); return
    try:
        target = int(args[0])
    except ValueError:
        send_msg(chat_id, "Invalid user ID."); return
    cfg = get_cfg()
    if target not in cfg["admin_ids"]:
        cfg["admin_ids"].append(target)
        save_cfg(cfg)
        send_msg(chat_id, f"User {target} is now an admin.")
    else:
        cfg["admin_ids"].remove(target)
        save_cfg(cfg)
        send_msg(chat_id, f"User {target} admin access removed.")

def handle_ban(chat_id: int, uid: int, args: list, reply_uid: int = None):
    if not is_admin(uid):
        return
    target = reply_uid
    if not target and args:
        try: target = int(args[0])
        except ValueError: pass
    if not target:
        send_msg(chat_id, "Usage: /ban USER_ID or reply to a message"); return
    cfg = get_cfg()
    if target not in cfg["banned_users"]:
        cfg["banned_users"].append(target)
        save_cfg(cfg)
        send_msg(chat_id, f"User {target} banned.")
    else:
        cfg["banned_users"].remove(target)
        save_cfg(cfg)
        send_msg(chat_id, f"User {target} unbanned.")

def handle_limit(chat_id: int, uid: int, args: list):
    if not is_admin(uid):
        return
    cfg = get_cfg()
    if len(args) == 2:
        try:
            target = int(args[0]); mult = float(args[1])
        except ValueError:
            send_msg(chat_id, "Usage: /limit USER_ID MULTIPLIER"); return
        cfg["user_limit_multipliers"][str(target)] = mult
        save_cfg(cfg)
        send_msg(chat_id, f"User {target} limit set to {mult}x")
    elif len(args) == 1:
        try: mult = float(args[0])
        except ValueError:
            send_msg(chat_id, "Usage: /limit MULTIPLIER"); return
        cfg["user_limit_multipliers"]["global"] = mult
        save_cfg(cfg)
        send_msg(chat_id, f"Global limit set to {mult}x")
    else:
        send_msg(chat_id, "Usage:\n/limit MULTIPLIER — global\n/limit USER_ID MULTIPLIER — per user")

def handle_stats(chat_id: int, uid: int):
    if not is_admin(uid):
        return
    cfg   = get_cfg()
    total_msgs  = sum(len([t for t in d.get("messages",[]) if t > _window()]) for d in _usage.values())
    total_srch  = sum(len([t for t in d.get("searches",[]) if t > _window()]) for d in _usage.values())
    total_imgs  = sum(len([t for t in d.get("images",  []) if t > _window()]) for d in _usage.values())
    send_msg(chat_id,
        "<b>Stats (last hour)</b>\n\n"
        f"Active users: {len(_usage)}\n"
        f"Messages:     {total_msgs}\n"
        f"Searches:     {total_srch}\n"
        f"Images:       {total_imgs}\n"
        f"Banned:       {len(cfg.get('banned_users',[]))}\n\n"
        f"Gemini keys:  {len(cfg.get('gemini_keys',[]))}\n"
        f"Grok keys:    {len(cfg.get('grok_keys',[]))}\n"
        f"Mistral keys: {len(cfg.get('mistral_keys',[]))}"
    )

# =============================================================================
# CALLBACK HANDLER
# =============================================================================
def handle_callback(cb_id: str, uid: int, chat_id: int, msg_id: int, data: str):
    answer_cb(cb_id)

    if data == "open:main":
        edit_msg(chat_id, msg_id, "Main menu:", main_markup(uid))

    elif data == "open:switch":
        edit_msg(chat_id, msg_id, "Select AI model:", switch_markup(uid))

    elif data == "open:voice":
        voice_on, _ = get_voice(uid)
        state = "ON" if voice_on else "OFF"
        edit_msg(chat_id, msg_id, f"Voice replies: <b>{state}</b>\nSelect a voice:", voice_markup(uid))

    elif data == "open:webprompt":
        edit_msg(chat_id, msg_id, "Send your search query as a message.\nOr use /web your query")

    elif data == "cmd:new":
        reset_sess(uid)
        edit_msg(chat_id, msg_id, "Chat history cleared.", main_markup(uid))

    elif data.startswith("switch:"):
        model = data.split(":")[1]
        set_model(uid, model)
        labels = {"lite": "Void Lite", "flash": "Void Flash", "pro": "Void Pro"}
        edit_msg(chat_id, msg_id, f"Switched to <b>{labels.get(model, model)}</b>.", main_markup(uid))

    elif data.startswith("voice:"):
        code = data.split(":", 1)[1]
        if code == "toggle":
            voice_on, vn = get_voice(uid)
            set_voice(uid, not voice_on, vn)
            new_state = "ON" if not voice_on else "OFF"
            edit_msg(chat_id, msg_id, f"Voice replies turned <b>{new_state}</b>.", voice_markup(uid))
        else:
            set_voice(uid, True, code)
            display = {v: k for k, v in INDIAN_VOICES.items()}.get(code, code)
            edit_msg(chat_id, msg_id, f"Voice: <b>{esc(display)}</b> selected. Voice replies ON.", main_markup(uid))

    elif data.startswith("admin:"):
        if not is_admin(uid):
            return
        action = data.split(":")[1]
        cfg = get_cfg()
        if action == "stats":
            handle_stats(chat_id, uid)
        elif action == "keys":
            lines = ["<b>API Keys</b>\n"]
            for p, f in [("Gemini","gemini_keys"),("Grok","grok_keys"),("Mistral","mistral_keys")]:
                keys = cfg.get(f, [])
                lines.append(f"<b>{p}</b>: {len(keys)} key(s)")
                for i, k in enumerate(keys, 1):
                    lines.append(f"  {i}. ...{k[-8:]}")
            lines.append("\n/addkey provider KEY\n/delkey provider INDEX")
            edit_msg(chat_id, msg_id, "\n".join(lines))
        elif action == "bans":
            bans = cfg.get("banned_users", [])
            text = "<b>Banned Users</b>\n\n"
            text += "\n".join(str(b) for b in bans) if bans else "None"
            edit_msg(chat_id, msg_id, text)
        elif action == "limits":
            limits = cfg.get("limits", {})
            lines = ["<b>Limits (per hour)</b>\n"]
            for tier in ("lite", "flash", "pro"):
                lim = limits.get(tier, {})
                lines.append(f"<b>{tier.capitalize()}</b>: msgs={lim.get('messages','?')} imgs={lim.get('images','?')} searches={lim.get('searches','?')}")
            lines.append("\n/limit MULTIPLIER — global\n/limit USER_ID MULTIPLIER — per user")
            edit_msg(chat_id, msg_id, "\n".join(lines))

# =============================================================================
# MAIN LOOP
# =============================================================================
def main():
    print(f"VoidAI starting... Admin ID: {BOOTSTRAP_ADMIN}")
    print(f"Config file: {CONFIG_FILE}")
    offset = None

    while True:
        try:
            updates = get_updates(offset)
            for update in updates:
                offset = update["update_id"] + 1
                try:
                    process_update(update)
                except Exception as e:
                    print(f"[UPDATE] error: {e}")
        except Exception as e:
            print(f"[LOOP] error: {e}")
            time.sleep(3)

def process_update(update: dict):
    # ── Callback query ─────────────────────────────────────────────────────────
    if "callback_query" in update:
        cq      = update["callback_query"]
        uid     = cq["from"]["id"]
        cb_id   = cq["id"]
        data    = cq.get("data", "")
        msg     = cq.get("message", {})
        chat_id = msg.get("chat", {}).get("id")
        msg_id  = msg.get("message_id", 0)
        if chat_id:
            handle_callback(cb_id, uid, chat_id, msg_id, data)
        return

    msg     = update.get("message", {})
    chat_id = msg.get("chat", {}).get("id")
    if not chat_id:
        return

    uid     = msg.get("from", {}).get("id", 0)
    name    = msg.get("from", {}).get("first_name", "there")
    text    = (msg.get("text") or "").strip()
    photos  = msg.get("photo", [])
    caption = (msg.get("caption") or "").strip()

    if is_banned(uid):
        return

    # ── Commands ────────────────────────────────────────────────────────────────
    if text.startswith("/"):
        parts   = text.split()
        command = parts[0].split("@")[0].lower()
        args    = parts[1:]
        reply_uid = msg.get("reply_to_message", {}).get("from", {}).get("id")

        if command == "/start":       handle_start(chat_id, uid, name)
        elif command == "/help":      handle_help(chat_id)
        elif command == "/new":       handle_new(chat_id, uid)
        elif command == "/switch":    handle_switch(chat_id, uid)
        elif command == "/voice":     handle_voice_cmd(chat_id, uid)
        elif command == "/web":       handle_web_cmd(chat_id, uid, " ".join(args))
        elif command == "/admin":     handle_admin(chat_id, uid)
        elif command == "/addkey":    handle_addkey(chat_id, uid, args)
        elif command == "/delkey":    handle_delkey(chat_id, uid, args)
        elif command == "/listkeys":  handle_listkeys(chat_id, uid)
        elif command == "/addadmin":  handle_addadmin(chat_id, uid, args)
        elif command == "/ban":       handle_ban(chat_id, uid, args, reply_uid)
        elif command == "/limit":     handle_limit(chat_id, uid, args)
        elif command == "/stats":     handle_stats(chat_id, uid)
        return

    # ── Photo ───────────────────────────────────────────────────────────────────
    if photos:
        threading.Thread(
            target=handle_image,
            args=(chat_id, uid, photos, caption),
            daemon=True,
        ).start()
        return

    # ── Text message ─────────────────────────────────────────────────────────────
    if text:
        threading.Thread(
            target=handle_question,
            args=(chat_id, uid, text),
            daemon=True,
        ).start()

if __name__ == "__main__":
    main()
