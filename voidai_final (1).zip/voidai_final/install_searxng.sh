#!/bin/bash
# =====================================================
#  SearXNG Self-Host Installer
#  Works on: Ubuntu 20/22/24, Debian, Oracle Linux 8/9
#  RAM needed: ~300MB (your 6GB is plenty)
#  After install: runs on http://127.0.0.1:8080
# =====================================================

set -e

echo ""
echo "====================================="
echo "  SearXNG Installer"
echo "====================================="
echo ""

# ── Detect OS ──────────────────────────────────────────
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$ID
else
    OS="unknown"
fi
echo "[*] Detected OS: $OS"

# ── Install dependencies ───────────────────────────────
if [[ "$OS" == "ubuntu" || "$OS" == "debian" ]]; then
    echo "[*] Installing dependencies (apt)..."
    sudo apt-get update -q
    sudo apt-get install -y python3 python3-pip python3-venv git curl

elif [[ "$OS" == "ol" || "$OS" == "rhel" || "$OS" == "centos" || "$OS" == "fedora" ]]; then
    echo "[*] Installing dependencies (dnf)..."
    sudo dnf install -y python3 python3-pip git curl

else
    echo "[!] Unknown OS. Trying to continue anyway..."
fi

# ── Clone SearXNG ──────────────────────────────────────
INSTALL_DIR="$HOME/searxng"

if [ -d "$INSTALL_DIR" ]; then
    echo "[*] SearXNG already cloned, pulling latest..."
    cd "$INSTALL_DIR" && git pull
else
    echo "[*] Cloning SearXNG..."
    git clone https://github.com/searxng/searxng.git "$INSTALL_DIR"
fi

cd "$INSTALL_DIR"

# ── Python venv ────────────────────────────────────────
echo "[*] Setting up Python virtual environment..."
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip -q
pip install -e . -q

# ── Config ────────────────────────────────────────────
SETTINGS_DIR="$HOME/searxng-settings"
mkdir -p "$SETTINGS_DIR"

cat > "$SETTINGS_DIR/settings.yml" << 'YAML'
use_default_settings: true

general:
  debug: false
  instance_name: "VoidAI Search"

search:
  safe_search: 0
  autocomplete: ""
  default_lang: "en"

server:
  port: 8080
  bind_address: "127.0.0.1"   # only local — bot accesses it, not public
  secret_key: "voidai_searxng_secret_change_this"
  limiter: false               # no rate limiting since it's local only
  public_instance: false
  image_proxy: false

ui:
  static_use_hash: false

outgoing:
  request_timeout: 8.0
  max_request_timeout: 15.0
  useragent_suffix: ""
  pool_connections: 10
  pool_maxsize: 20

# Engines to use — good balance of speed + coverage
engines:
  - name: google
    engine: google
    shortcut: g
    timeout: 8.0

  - name: bing
    engine: bing
    shortcut: b
    timeout: 8.0

  - name: duckduckgo
    engine: duckduckgo
    shortcut: d
    timeout: 8.0

  - name: brave
    engine: brave
    shortcut: br
    timeout: 8.0

  - name: wikipedia
    engine: wikipedia
    shortcut: w
    timeout: 5.0

  - name: wikidata
    engine: wikidata
    shortcut: wd
    timeout: 5.0
YAML

echo "[*] Config saved to $SETTINGS_DIR/settings.yml"

# ── Start script ───────────────────────────────────────
cat > "$HOME/start_searxng.sh" << STARTSCRIPT
#!/bin/bash
cd $INSTALL_DIR
source venv/bin/activate
export SEARXNG_SETTINGS_PATH=$SETTINGS_DIR/settings.yml
python searx/webapp.py
STARTSCRIPT
chmod +x "$HOME/start_searxng.sh"

# ── Systemd service (auto-start on reboot) ─────────────
SERVICE_FILE="/etc/systemd/system/searxng.service"
CURRENT_USER=$(whoami)

sudo tee "$SERVICE_FILE" > /dev/null << SVCEOF
[Unit]
Description=SearXNG Search Engine
After=network.target

[Service]
Type=simple
User=$CURRENT_USER
WorkingDirectory=$INSTALL_DIR
Environment=SEARXNG_SETTINGS_PATH=$SETTINGS_DIR/settings.yml
ExecStart=$INSTALL_DIR/venv/bin/python searx/webapp.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SVCEOF

sudo systemctl daemon-reload
sudo systemctl enable searxng
sudo systemctl start searxng

echo ""
echo "====================================="
echo "  SearXNG Install Complete!"
echo "====================================="
echo ""
echo "Status:   $(sudo systemctl is-active searxng)"
echo "URL:      http://127.0.0.1:8080"
echo "Test:     curl 'http://127.0.0.1:8080/search?q=test&format=json'"
echo ""
echo "Manage:"
echo "  sudo systemctl start searxng"
echo "  sudo systemctl stop searxng"
echo "  sudo systemctl restart searxng"
echo "  sudo systemctl status searxng"
echo ""
echo "Your bot already has SEARXNG_URL = 'http://127.0.0.1:8080'"
echo "It will auto-use SearXNG for all searches now."
echo ""
